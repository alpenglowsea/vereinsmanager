import React, { useState, useMemo } from 'react';
import {
  ScrollText,
  Plus,
  Search,
  FileText,
  Download,
  Sliders,
  CheckCircle2,
  Clock,
  Calendar,
  Building,
  Scale,
  ShieldCheck,
  Trash2,
  Edit,
  Users,
  Check,
  BookOpen,
  Mail,
  PenTool,
  X
} from 'lucide-react';
import {
  Meeting,
  MeetingType,
  MeetingStatus,
  MeetingTemplateSettings,
  ClubSettings,
  Member,
  InvoiceTemplateSettings
} from '../types';
import { MeetingPdfService, briefpapierFuerSitzungen } from '../services/meetingPdfService';
import { MeetingFormModal } from './MeetingFormModal';
import { MeetingTemplateModal } from './MeetingTemplateModal';
import { MeetingSignatureModal } from './MeetingSignatureModal';
import { MeetingEmailModal } from './MeetingEmailModal';
import { savePdfAs } from '../utils/fileExportHelper';
import { melde, bestaetige, frage } from '../utils/dialoge';
import {
  SITZUNGSARTEN,
  SITZUNGSSTATUS,
  auszugFehlt,
  deutsch,
  einladungFehlt,
  filtern,
  gesperrt,
  leitungsUnterschrift,
  pruefeUnterschrift,
  schriftUnterschrift,
  statistik,
  statusName,
  unterschriftenEntfernen
} from '../utils/sitzungRegeln';

interface MeetingsViewProps {
  meetings: Meeting[];
  members: Member[];
  clubSettings: ClubSettings;
  templateSettings: MeetingTemplateSettings;
  onSaveMeeting: (meeting: Meeting) => Promise<void>;
  onDeleteMeeting: (meetingId: string) => Promise<void>;
  onSaveTemplate: (settings: MeetingTemplateSettings) => Promise<void>;
  /** Rechnungsvorlage: ihr Briefpapier gilt auch für Sitzungen (D-123) */
  invoiceTemplateSettings?: InvoiceTemplateSettings;
  onOpenBriefpapier?: () => void;
}

export const MeetingsView: React.FC<MeetingsViewProps> = ({
  meetings,
  members,
  clubSettings,
  templateSettings,
  onSaveMeeting,
  onDeleteMeeting,
  onSaveTemplate,
  invoiceTemplateSettings,
  onOpenBriefpapier,
}) => {
  /**
   * Klick auf einen ändernden Knopf. Ohne Schreibrecht wird nicht die
   * Aktion ausgeführt, sondern der Hinweis gezeigt.
   */
  const [activeTab, setActiveTab] = useState<'meetings' | 'resolutions' | 'template'>('meetings');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Modal states
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [meetingToEdit, setMeetingToEdit] = useState<Meeting | null>(null);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [generatingPdfId, setGeneratingPdfId] = useState<string | null>(null);
  const [generatingInvitationId, setGeneratingInvitationId] = useState<string | null>(null);
  const [signatureModalMeeting, setSignatureModalMeeting] = useState<Meeting | null>(null);
  const [emailModalConfig, setEmailModalConfig] = useState<{
    isOpen: boolean;
    meeting: Meeting;
    mode: 'invitation' | 'protocol';
  } | null>(null);
  const [downloadChoice, setDownloadChoice] = useState<{
    meeting: Meeting;
    isExtract: boolean;
  } | null>(null);

  // Briefpapier: das der Rechnungsvorlage gilt für alle Dokumente (D-123)
  const briefpapier = useMemo(
    () => briefpapierFuerSitzungen(templateSettings, invoiceTemplateSettings),
    [templateSettings, invoiceTemplateSettings]
  );

  // Kennzahlen: Finanzamt und Register zählen nur angenommene Beschlüsse (D-128)
  const stats = useMemo(() => statistik(meetings), [meetings]);

  // Filter: Art genau, auch Abteilungs- und sonstige Sitzungen (D-121)
  const filteredMeetings = useMemo(
    () => filtern(meetings, searchQuery, selectedType === 'all' ? null : selectedType, selectedStatus === 'all' ? null : selectedStatus),
    [meetings, selectedType, selectedStatus, searchQuery]
  );

  // All resolutions flattened for the Beschlussbuch
  const allResolutions = useMemo(() => {
    const list: Array<{
      meeting: Meeting;
      agendaNumber: string;
      agendaTitle: string;
      resolution: import('../types').MeetingResolution;
    }> = [];

    meetings.forEach(m => {
      m.agenda.forEach(top => {
        (top.resolutions || []).forEach(res => {
          list.push({
            meeting: m,
            agendaNumber: top.number,
            agendaTitle: top.title,
            resolution: res
          });
        });
      });
    });

    // Neueste Sitzung zuerst, innerhalb einer Sitzung in Reihenfolge der Tagesordnung
    return list.sort((a, b) =>
      b.meeting.date !== a.meeting.date
        ? b.meeting.date.localeCompare(a.meeting.date)
        : (b.meeting.startTime || '').localeCompare(a.meeting.startTime || '')
    );
  }, [meetings]);
  const anzahlSteuer = allResolutions.filter(i => i.resolution.isTaxRelevant).length;
  const anzahlRegister = allResolutions.filter(i => i.resolution.isRegisterRelevant).length;

  const [resolutionFilter, setResolutionFilter] = useState<'all' | 'tax' | 'register'>('all');

  const filteredResolutions = useMemo(() => {
    return allResolutions.filter(item => {
      if (resolutionFilter === 'tax' && !item.resolution.isTaxRelevant) return false;
      if (resolutionFilter === 'register' && !item.resolution.isRegisterRelevant) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          item.resolution.title.toLowerCase().includes(q) ||
          item.resolution.motionText.toLowerCase().includes(q) ||
          item.meeting.title.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [allResolutions, resolutionFilter, searchQuery]);

  const handleCreateMeeting = () => {
    setMeetingToEdit(null);
    setIsFormModalOpen(true);
  };

  /**
   * Unterschriebene Protokolle sind gesperrt (D-117). Statt still nichts zu
   * tun, wird angeboten, die Unterschriften zu entfernen.
   */
  const handleEditMeeting = async (m: Meeting) => {
    if (gesperrt(m)) {
      const ja = await frage({
        titel: 'Protokoll ist unterschrieben',
        text: 'Ein unterschriebenes Protokoll ist gesperrt. Zum Ändern müssen die Unterschriften entfernt werden; aus „Genehmigt“ wird dann „In Vorprüfung“, und beide müssen erneut unterschreiben.',
        bestaetigenText: 'Unterschriften entfernen und bearbeiten',
        gefahr: true
      });
      if (!ja) return;
      const frei = unterschriftenEntfernen(m);
      await onSaveMeeting(frei);
      setMeetingToEdit(frei);
      setIsFormModalOpen(true);
      return;
    }
    setMeetingToEdit(m);
    setIsFormModalOpen(true);
  };

  const handleInitiateDownloadPdf = (m: Meeting, isExtract: boolean = false) => {
    // Registerauszug nur mit festgestellter Beschlussfähigkeit und angenommenem, gekennzeichnetem Beschluss (D-127)
    if (isExtract) {
      const grund = auszugFehlt(m);
      if (grund) {
        void melde(`Ein Registerauszug ist nicht möglich: ${grund}`);
        return;
      }
    }
    // If the meeting has digital signatures, offer choice between digital signature and blank signature line
    if (m.signatures && m.signatures.length > 0) {
      setDownloadChoice({ meeting: m, isExtract });
    } else {
      handleExecuteDownloadPdf(m, isExtract, false);
    }
  };

  const handleExecuteDownloadPdf = async (m: Meeting, isExtract: boolean, withDigitalSignatures: boolean) => {
    setGeneratingPdfId(m.id);
    try {
      let doc;
      const suffix = withDigitalSignatures ? 'digital_signiert' : 'blanko_ausdruck';
      const safeTitle = (m.title || 'Sitzung').replace(/[^a-zA-Z0-9äöüÄÖÜß_-]/g, '_');

      if (isExtract) {
        doc = await MeetingPdfService.generateRegisterExtractPdf(m, clubSettings, templateSettings, {
          includeDigitalSignatures: withDigitalSignatures,
          briefpapier
        });
        void savePdfAs(doc, `Registerauszug_${m.date}_${safeTitle}_${suffix}.pdf`);
      } else {
        doc = await MeetingPdfService.generateProtocolPdf(m, clubSettings, templateSettings, {
          includeDigitalSignatures: withDigitalSignatures,
          briefpapier
        });
        void savePdfAs(doc, `Protokoll_${m.date}_${safeTitle}_${suffix}.pdf`);
      }
    } catch (err) {
      console.error('Failed to generate meeting PDF:', err);
      void melde('Fehler beim Erzeugen des Protokoll-PDFs.');
    } finally {
      setGeneratingPdfId(null);
      setDownloadChoice(null);
    }
  };

  const handleDownloadInvitationPdf = async (m: Meeting) => {
    const fehlt = einladungFehlt(m);
    if (fehlt.length) {
      void melde(`Für die Einladung fehlt noch: ${fehlt.join(', ')}. Bitte in der Sitzung ergänzen.`);
      return;
    }
    setGeneratingInvitationId(m.id);
    try {
      const doc = await MeetingPdfService.generateInvitationPdf(
        {
          title: m.title,
          type: m.type,
          date: m.date,
          startTime: m.startTime,
          endTime: m.endTime,
          location: m.location,
          chairperson: m.chairperson,
          minuteKeeper: m.minuteKeeper,
          invitationDate: m.invitationDate,
          agenda: m.agenda
        },
        clubSettings,
        templateSettings,
        { briefpapier }
      );
      void savePdfAs(doc, `Einladung_${m.date}_${m.title.replace(/[^a-zA-Z0-9äöüÄÖÜß_-]/g, '_')}.pdf`);
    } catch (err) {
      console.error('Failed to generate invitation PDF:', err);
      void melde('Fehler beim Erzeugen des Einladungs-PDFs.');
    } finally {
      setGeneratingInvitationId(null);
    }
  };

  const getStatusBadge = (status: MeetingStatus) => {
    switch (status) {
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-200 dark:border-emerald-800/60">
            <Check className="w-3 h-3" /> Genehmigt
          </span>
        );
      case 'review':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200 dark:bg-amber-900/40 dark:text-amber-200 dark:border-amber-800/60">
            <Clock className="w-3 h-3" /> In Vorprüfung
          </span>
        );
      case 'draft':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-700 dark:text-slate-200 dark:border-slate-800">
            <FileText className="w-3 h-3" /> Protokoll-Entwurf
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200 dark:bg-blue-900/40 dark:text-blue-200 dark:border-blue-800/60">
            <Clock className="w-3 h-3" /> In Durchführung
          </span>
        );
      case 'scheduled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200 dark:bg-indigo-900/40 dark:text-indigo-200 dark:border-indigo-800/60">
            <Calendar className="w-3 h-3" /> Einberufen / Geplant
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-200 text-slate-700 border border-slate-300 line-through decoration-slate-400 dark:bg-slate-700 dark:text-slate-200 dark:border-slate-600">
            Abgesagt
          </span>
        );
      default:
        // Unbekannter Status: deutscher Name, sonst das gespeicherte Wort (D-129)
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300">
            {statusName(status)}
          </span>
        );
    }
  };

  const getTypeBadge = (type: MeetingType) => {
    switch (type) {
      case 'board':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-200">
            Vorstandssitzung
          </span>
        );
      case 'general_assembly':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200">
            Mitgliederversammlung
          </span>
        );
      case 'extraordinary_assembly':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-200">
            Außerordentliche MV
          </span>
        );
      case 'committee':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-200">
            Ausschuss / Fachbereich
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-200">
            {SITZUNGSARTEN[type] ?? 'Sitzung'}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs dark:bg-slate-900 dark:border-slate-800">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center shadow-xs dark:bg-rose-950/40 dark:text-rose-400">
            <ScrollText className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Sitzungs- & Protokolldienst
            </h1>
            <p className="text-xs text-slate-500 mt-0.5 dark:text-slate-400">
              Vorstandssitzungen & Mitgliederversammlungen rechtssicher protokollieren.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
          <button
            type="button"
            onClick={handleCreateMeeting}
            className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
            title="Neue Sitzung anlegen"
          >
            <Plus className="w-4 h-4" />
            <span>Neue Sitzung erfassen</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs dark:bg-slate-900 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 mb-1 dark:text-slate-400">
            <span className="text-xs font-semibold">Sitzungen gesamt</span>
            <Calendar className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">{stats.gesamt}</div>
          <div className="text-[11px] text-slate-500 mt-1 dark:text-slate-400">
            {stats.vorstand} Vorstandssitzungen • {stats.versammlungen} Versammlungen
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs dark:bg-slate-900 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 mb-1 dark:text-slate-400">
            <span className="text-xs font-semibold">Beschlüsse angenommen</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{stats.angenommen}</div>
          <div className="text-[11px] text-slate-500 mt-1 dark:text-slate-400">
            {stats.abgelehnt} abgelehnt • {stats.vertagt} vertagt
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs dark:bg-slate-900 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 mb-1 dark:text-slate-400">
            <span className="text-xs font-semibold">Finanzamt-relevant</span>
            <Building className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-black text-blue-600 dark:text-blue-400">{stats.steuer}</div>
          <div className="text-[11px] text-slate-500 mt-1 dark:text-slate-400">
            angenommene Beschlüsse mit diesem Kennzeichen
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs dark:bg-slate-900 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 mb-1 dark:text-slate-400">
            <span className="text-xs font-semibold">Vereinsregister / Notar</span>
            <Scale className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-black text-rose-600 dark:text-rose-400">{stats.register}</div>
          <div className="text-[11px] text-slate-500 mt-1 dark:text-slate-400">
            angenommene Beschlüsse mit diesem Kennzeichen
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-slate-200 flex items-center gap-4 sm:gap-6 overflow-x-auto no-scrollbar dark:border-slate-800">
        <button
          type="button"
          onClick={() => setActiveTab('meetings')}
          className={`py-3 text-xs font-bold border-b-2 transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap shrink-0 ${
            activeTab === 'meetings'
              ? 'border-rose-600 text-rose-600 dark:text-rose-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100'
          }`}
        >
          <ScrollText className="w-4 h-4 shrink-0" />
          <span>Sitzungen & Protokolle ({meetings.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('resolutions')}
          className={`py-3 text-xs font-bold border-b-2 transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap shrink-0 ${
            activeTab === 'resolutions'
              ? 'border-rose-600 text-rose-600 dark:text-rose-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100'
          }`}
        >
          <BookOpen className="w-4 h-4 shrink-0" />
          <span>Beschlussbuch / Beschlussregister ({allResolutions.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('template')}
          className={`py-3 text-xs font-bold border-b-2 transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap shrink-0 ${
            activeTab === 'template'
              ? 'border-rose-600 text-rose-600 dark:text-rose-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100'
          }`}
        >
          <Sliders className="w-4 h-4 shrink-0" />
          <span>Vorlagen & Vereinsbriefpapier</span>
        </button>
      </div>

      {/* TAB 1: SITZUNGEN & PROTOKOLLE */}
      {activeTab === 'meetings' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200 dark:bg-slate-900 dark:border-slate-800">
            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Sitzung, TOP, Beschluss suchen..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-rose-500 dark:bg-slate-800 dark:border-slate-800 dark:text-slate-100 dark:focus:bg-slate-800"
                />
              </div>

              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 dark:bg-slate-800 dark:border-slate-800 dark:text-slate-200"
              >
                <option value="all">Alle Sitzungsarten</option>
                {(Object.keys(SITZUNGSARTEN) as MeetingType[]).map((a) => (
                  <option key={a} value={a}>
                    {SITZUNGSARTEN[a]}
                  </option>
                ))}
              </select>

              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 dark:bg-slate-800 dark:border-slate-800 dark:text-slate-200"
              >
                <option value="all">Alle Status</option>
                {(Object.keys(SITZUNGSSTATUS) as MeetingStatus[]).map((st) => (
                  <option key={st} value={st}>
                    {SITZUNGSSTATUS[st]}
                  </option>
                ))}
              </select>
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400">
              {filteredMeetings.length} von {meetings.length} Sitzungen
            </div>
          </div>

          {/* Meeting Cards List */}
          {filteredMeetings.length === 0 ? (
            <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 space-y-3 dark:bg-slate-900 dark:border-slate-800">
              <ScrollText className="w-10 h-10 text-slate-300 mx-auto" />
              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-200">Keine Sitzungen gefunden</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto dark:text-slate-400">
                Legen Sie eine neue Vorstandssitzung oder Mitgliederversammlung an, um die Tagesordnung und Beschlüsse rechtssicher zu dokumentieren.
              </p>
              <button
                type="button"
                onClick={handleCreateMeeting}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700 cursor-pointer shadow-xs"
                title="Neue Sitzung anlegen"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Neue Sitzung anlegen</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3.5">
              {filteredMeetings.map((m) => {
                const totalResolutionsInMeeting = m.agenda.reduce(
                  (acc, top) => acc + (top.resolutions?.length || 0),
                  0
                );
                // Registerauszug anbieten, sobald ein Beschluss dafür gekennzeichnet ist;
                // ob er möglich ist, sagt der Knopf beim Klick (auszugFehlt)
                const needsRegisterExtract = m.agenda.some((top) => top.resolutions?.some((r) => r.isRegisterRelevant));
                const anzahlSig = (leitungsUnterschrift(m) ? 1 : 0) + (schriftUnterschrift(m) ? 1 : 0);
                const textGeaendert = (m.signatures || []).some((sg) => pruefeUnterschrift(m, sg) === 'geaendert');

                return (
                  <div
                    key={m.id}
                    className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs hover:border-slate-300 transition-all space-y-4 dark:bg-slate-800 dark:border-slate-800 dark:hover:border-slate-700"
                  >
                    {/* Obere Leiste: Status-Badges & Aktions-Buttons */}
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex flex-wrap items-center gap-2">
                        {getTypeBadge(m.type)}
                        {getStatusBadge(m.status)}
                        {m.quorumConfirmed && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded dark:text-slate-300 dark:bg-slate-700">
                            <ShieldCheck className="w-3 h-3 text-emerald-600 dark:text-emerald-400" /> Beschlussfähig
                          </span>
                        )}
                        {m.invitationCompliant && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded dark:text-slate-300 dark:bg-slate-700">
                            <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" /> Fristgerecht geladen
                          </span>
                        )}

                        {/* Digital Signature Badge / Button */}
                        {m.signatures && m.signatures.length > 0 ? (
                          <button
                            type="button"
                            onClick={() => setSignatureModalMeeting(m)}
                            className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2.5 py-0.5 rounded-full transition-colors cursor-pointer dark:text-emerald-200 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/40 dark:border-emerald-800/60"
                            title="Digitale Signaturen einsehen oder aktualisieren"
                          >
                            <PenTool className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                            <span>{anzahlSig}/2 unterschrieben • gesperrt</span>
                          </button>
                        ) : m.status === 'cancelled' ? null : (
                          <button
                            type="button"
                            onClick={() => setSignatureModalMeeting(m)}
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 px-2 py-0.5 rounded-full transition-colors cursor-pointer shadow-2xs dark:text-slate-300 dark:hover:text-white dark:bg-slate-900 dark:hover:bg-slate-800 dark:border-slate-800"
                            title="Protokoll am PC mit Maus oder am Smartphone mit Finger digital unterzeichnen"
                          >
                            <PenTool className="w-3 h-3 text-rose-500" />
                            <span>Digital unterschreiben</span>
                          </button>
                        )}
                        {textGeaendert && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-800 bg-rose-100 border border-rose-200 px-2 py-0.5 rounded-full dark:text-rose-200 dark:bg-rose-900/40 dark:border-rose-800/60">
                            Text nach Unterschrift geändert
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {/* E-Mail Versand Button */}
                        <button
                          type="button"
                          onClick={() =>
                            setEmailModalConfig({
                              isOpen: true,
                              meeting: m,
                              mode: m.status === 'approved' ? 'protocol' : 'invitation'
                            })
                          }
                          className="h-7 px-2.5 text-xs font-semibold text-slate-600 hover:text-rose-700 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs whitespace-nowrap shrink-0 dark:text-slate-300 dark:hover:text-rose-300 dark:hover:bg-rose-950/40 dark:border-slate-800 dark:hover:border-rose-800/60"
                          title="Einladung oder Protokoll per E-Mail an Mitglieder/Teilnehmer versenden (DSGVO-konform mit BCC)"
                        >
                          <Mail className="w-3.5 h-3.5 text-rose-600 shrink-0 dark:text-rose-400" />
                          <span>E-Mail versenden</span>
                        </button>

                        <button
                          type="button"
                          onClick={async () => {
                            if (await bestaetige(`Möchten Sie die Sitzung "${m.title}" wirklich löschen?`)) {
                              onDeleteMeeting(m.id);
                            }
                          }}
                          className="h-7 w-7 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors flex items-center justify-center cursor-pointer shrink-0 dark:hover:text-rose-400 dark:hover:bg-rose-950/40"
                          title="Sitzung löschen"
                        >
                          <Trash2 className="w-4 h-4 shrink-0" />
                        </button>
                      </div>
                    </div>

                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 min-w-0">
                      <div className="space-y-1 min-w-0 flex-1">
                        <h3 className="text-base font-bold text-slate-900 mt-0.5 break-words dark:text-white">
                          {m.title}
                        </h3>

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 pt-0.5 dark:text-slate-400">
                          <span className="flex items-center gap-1 shrink-0">
                            <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            {deutsch(m.date)}
                          </span>
                          {m.startTime && (
                            <span className="flex items-center gap-1 shrink-0">
                              <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              {m.startTime} Uhr{m.endTime ? ` – ${m.endTime} Uhr` : ''}
                            </span>
                          )}
                          {m.location && (
                            <span className="flex items-center gap-1 shrink-0">
                              <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span className="truncate max-w-[200px]">{m.location}</span>
                            </span>
                          )}
                          <span className="flex items-center gap-1 flex-wrap">
                            <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>Leitung: {m.chairperson || '–'} • Protokoll: {m.minuteKeeper || '–'}</span>
                          </span>
                        </div>
                      </div>

                      {/* Quick Action Buttons: 2 Zeilen harmonisch ausgerichtet (1. Zeile: Einladung, Protokoll; 2. Zeile: Register-Auszug, Bearbeiten) */}
                      <div className="flex flex-col gap-2 shrink-0 self-stretch sm:self-start lg:self-center pt-2 lg:pt-0 w-full sm:w-[310px]">
                        {/* 1. Zeile: Einladung, Protokoll */}
                        <div className="grid grid-cols-2 gap-2 w-full">
                          <button
                            type="button"
                            onClick={() => handleDownloadInvitationPdf(m)}
                            disabled={generatingInvitationId === m.id}
                            className="h-8.5 px-3 text-xs font-semibold bg-white border border-rose-200 text-rose-700 hover:bg-rose-50 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs min-w-0 dark:bg-slate-900 dark:border-rose-800/60 dark:text-rose-300 dark:hover:bg-rose-950/40"
                            title="Form- und fristgerechtes Einladungsschreiben mit Tagesordnung gem. § 32 BGB als PDF herunterladen"
                          >
                            <Mail className="w-3.5 h-3.5 text-rose-600 shrink-0 dark:text-rose-400" />
                            <span className="truncate">{generatingInvitationId === m.id ? 'Erzeuge...' : 'Einladung'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleInitiateDownloadPdf(m, false)}
                            disabled={generatingPdfId === m.id}
                            className="h-8.5 px-3 text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs min-w-0 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800/60 dark:hover:bg-rose-900/40"
                            title="Vollständiges Sitzungsprotokoll als PDF herunterladen"
                          >
                            <Download className="w-3.5 h-3.5 shrink-0 text-rose-600 dark:text-rose-400" />
                            <span className="truncate">{generatingPdfId === m.id ? 'Erzeuge...' : 'Protokoll'}</span>
                          </button>
                        </div>

                        {/* 2. Zeile: Register-Auszug (nur wenn relevant) & Bearbeiten */}
                        <div className="grid grid-cols-2 gap-2 w-full">
                          {needsRegisterExtract ? (
                            <>
                              <button
                                type="button"
                                onClick={() => handleInitiateDownloadPdf(m, true)}
                                disabled={generatingPdfId === m.id}
                                className="h-8.5 px-2.5 text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer min-w-0 dark:bg-slate-700 dark:text-slate-200 dark:hover:bg-slate-600"
                                title="Auszug für Notar / Amtsgericht (Vereinsregister)"
                              >
                                <Scale className="w-3.5 h-3.5 text-rose-600 shrink-0 dark:text-rose-400" />
                                <span className="truncate">{generatingPdfId === m.id ? 'Erzeuge...' : 'Register-Auszug'}</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleEditMeeting(m)}
                                className="h-8.5 px-3 text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs min-w-0 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-200 dark:hover:bg-slate-800"
                                title="Sitzung und Protokolldaten bearbeiten"
                              >
                                <Edit className="w-3.5 h-3.5 shrink-0 text-slate-500 dark:text-slate-400" />
                                <span className="truncate">Bearbeiten</span>
                              </button>
                            </>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleEditMeeting(m)}
                              className="col-span-2 h-8.5 px-3 text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs min-w-0 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-200 dark:hover:bg-slate-800"
                              title="Sitzung und Protokolldaten bearbeiten"
                            >
                              <Edit className="w-3.5 h-3.5 shrink-0 text-slate-500 dark:text-slate-400" />
                              <span className="truncate">Bearbeiten</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* TOPs & Resolutions Preview */}
                    <div className="bg-slate-50/70 border border-slate-200/80 rounded-xl p-3.5 space-y-2 dark:bg-slate-800/70 dark:border-slate-800">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-200">
                        <span>Tagesordnung ({m.agenda.length} Punkte)</span>
                        <span className="text-slate-500 font-normal dark:text-slate-400">
                          {totalResolutionsInMeeting} {totalResolutionsInMeeting === 1 ? 'Beschluss' : 'Beschlüsse'}
                        </span>
                      </div>

                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {m.agenda.map((top) => {
                          const resCount = top.resolutions?.length || 0;
                          return (
                            <div
                              key={top.id}
                              className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs flex items-center gap-1.5 text-slate-700 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-200"
                            >
                              <span className="font-bold text-slate-900 dark:text-white">{top.number}</span>
                              <span className="truncate max-w-[220px]">{top.title}</span>
                              {resCount > 0 && (
                                <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px] dark:bg-emerald-900/40 dark:text-emerald-200">
                                  {resCount} Beschl.
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: BESCHLUSSBUCH / REGISTER */}
      {activeTab === 'resolutions' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200 dark:bg-slate-900 dark:border-slate-800">
            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-72">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Beschlüsse & Anträge filtern..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-rose-500 dark:bg-slate-800 dark:border-slate-800 dark:text-slate-100 dark:focus:bg-slate-800"
                />
              </div>

              <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-xs font-semibold dark:bg-slate-700">
                <button
                  type="button"
                  onClick={() => setResolutionFilter('all')}
                  className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                    resolutionFilter === 'all' ? 'bg-white text-slate-900 shadow-2xs dark:bg-slate-900 dark:text-white' : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                  }`}
                >
                  Alle ({allResolutions.length})
                </button>
                <button
                  type="button"
                  onClick={() => setResolutionFilter('tax')}
                  className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                    resolutionFilter === 'tax' ? 'bg-white text-blue-700 shadow-2xs font-bold dark:bg-slate-900 dark:text-blue-300' : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                  }`}
                >
                  Finanzamt ({anzahlSteuer})
                </button>
                <button
                  type="button"
                  onClick={() => setResolutionFilter('register')}
                  className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                    resolutionFilter === 'register' ? 'bg-white text-rose-700 shadow-2xs font-bold dark:bg-slate-900 dark:text-rose-300' : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                  }`}
                >
                  Vereinsregister ({anzahlRegister})
                </button>
              </div>
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400">
              {filteredResolutions.length} Beschlüsse
            </div>
          </div>

          {/* Resolutions Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs dark:bg-slate-900 dark:border-slate-800">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[750px] text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold dark:bg-slate-800 dark:border-slate-800 dark:text-slate-400">
                  <tr>
                    <th className="px-4 py-3">Datum & Sitzung</th>
                    <th className="px-4 py-3">TOP</th>
                    <th className="px-4 py-3">Beschlusstitel & Antragswortlaut</th>
                    <th className="px-4 py-3 text-center">Stimmen (J/N/E)</th>
                    <th className="px-4 py-3 text-center">Ergebnis</th>
                    <th className="px-4 py-3">Relevanz</th>
                    <th className="px-4 py-3">Verantwortlich</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredResolutions.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/60">
                      <td className="px-4 py-3">
                        <div className="font-bold text-slate-900 dark:text-white">
                          {deutsch(item.meeting.date)}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {item.meeting.title}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                        {item.agendaNumber}
                      </td>
                      <td className="px-4 py-3 max-w-md">
                        <div className="font-bold text-slate-900 dark:text-white">{item.resolution.title}</div>
                        <div className="text-slate-600 italic text-[11px] line-clamp-2 mt-0.5 dark:text-slate-300">
                          "{item.resolution.motionText}"
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center font-mono">
                        <span className="text-emerald-700 font-bold dark:text-emerald-300">{item.resolution.votesFor}</span>
                        <span className="text-slate-400 mx-1">/</span>
                        <span className="text-rose-700 font-bold dark:text-rose-300">{item.resolution.votesAgainst}</span>
                        <span className="text-slate-400 mx-1">/</span>
                        <span className="text-slate-500 dark:text-slate-400">{item.resolution.votesAbstain}</span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.resolution.result === 'accepted'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200'
                              : item.resolution.result === 'rejected'
                              ? 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200'
                          }`}
                        >
                          {item.resolution.result === 'accepted'
                            ? 'Angenommen'
                            : item.resolution.result === 'rejected'
                            ? 'Abgelehnt'
                            : 'Vertagt'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col gap-1">
                          {item.resolution.isTaxRelevant && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-blue-800 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200 dark:text-blue-200 dark:bg-blue-950/40 dark:border-blue-800/60">
                              Finanzamt / EÜR
                            </span>
                          )}
                          {item.resolution.isRegisterRelevant && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-800 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200 dark:text-rose-200 dark:bg-rose-950/40 dark:border-rose-800/60">
                              Vereinsregister § 26
                            </span>
                          )}
                          {!item.resolution.isTaxRelevant && !item.resolution.isRegisterRelevant && (
                            <span className="text-[11px] text-slate-400">Intern</span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-[11px] text-slate-600 dark:text-slate-300">
                        {item.resolution.responsiblePerson || '–'}
                        {item.resolution.dueDate && (
                          <div className="text-slate-400 text-[10px]">
                            Frist: {deutsch(item.resolution.dueDate)}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: VORLAGEN & BRIEFPAPIER */}
      {activeTab === 'template' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6 dark:bg-slate-900 dark:border-slate-800">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Briefpapier- & Layoutkonfiguration für Vereinsprotokolle
              </h3>
              <p className="text-xs text-slate-500 mt-1 dark:text-slate-400">
                Laden Sie Ihr offizielles Vereins-Briefpapier hoch oder passen Sie Ränder und Kopfzeilen an.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsTemplateModalOpen(true)}
              className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700 cursor-pointer shadow-xs flex items-center gap-2"
            >
              <Sliders className="w-4 h-4" />
              <span>Briefpapier konfigurieren</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-2 dark:border-slate-800 dark:bg-slate-800">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-100">Aktueller Status der Vorlage:</span>
                <div className="flex flex-wrap items-center gap-3">
                  {briefpapier ? (
                    <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1.5 rounded-lg dark:text-emerald-300 dark:bg-emerald-900/40">
                      <Check className="w-4 h-4" />
                      {briefpapier.quelle === 'rechnung'
                        ? `Briefpapier aus den Einstellungen (${invoiceTemplateSettings?.customBlankoFileName || 'Briefpapier'})`
                        : `Älteres Briefpapier nur für Sitzungen (${templateSettings.customBlankoFileName || 'Briefpapier'})`}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-700 bg-slate-200 px-3 py-1.5 rounded-lg dark:text-slate-200 dark:bg-slate-600">
                      <Building className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                      Standard-Vereinsbriefkopf (kein Briefpapier hinterlegt)
                    </div>
                  )}
                  {onOpenBriefpapier && (
                    <button
                      type="button"
                      onClick={onOpenBriefpapier}
                      className="px-3 py-1.5 text-xs font-bold text-rose-700 bg-white border border-rose-200 hover:bg-rose-50 rounded-lg dark:text-rose-300 dark:bg-slate-900 dark:border-rose-800/60"
                    >
                      Briefpapier in den Einstellungen ändern
                    </button>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Wie am Handy gilt ein gemeinsames Briefpapier für Rechnungen, Sitzungen und den Aufnahmeantrag; es wird unter Einstellungen → Vereinsstammdaten gepflegt.
                  {briefpapier?.quelle === 'sitzung' &&
                    ' Das ältere, nur für Sitzungen hochgeladene Briefpapier wird verwendet, bis dort eines liegt.'}
                </p>
              </div>

              <div className="border border-slate-200 rounded-xl p-4 space-y-3 dark:border-slate-800">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider dark:text-slate-100">
                  Druckränder & Layout-Parameter
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-2.5 bg-slate-50 rounded-lg dark:bg-slate-800">
                    <span className="text-slate-500 block text-[10px] dark:text-slate-400">Oberer Rand (Header)</span>
                    <span className="font-bold text-slate-900 dark:text-white">{templateSettings.marginTop} mm</span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg dark:bg-slate-800">
                    <span className="text-slate-500 block text-[10px] dark:text-slate-400">Unterer Rand (Footer)</span>
                    <span className="font-bold text-slate-900 dark:text-white">{templateSettings.marginBottom} mm</span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg dark:bg-slate-800">
                    <span className="text-slate-500 block text-[10px] dark:text-slate-400">Linker Rand</span>
                    <span className="font-bold text-slate-900 dark:text-white">{templateSettings.marginLeft} mm</span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg dark:bg-slate-800">
                    <span className="text-slate-500 block text-[10px] dark:text-slate-400">Rechter Rand</span>
                    <span className="font-bold text-slate-900 dark:text-white">{templateSettings.marginRight} mm</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Visual Mini Preview */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-100 flex flex-col items-center justify-center text-center dark:border-slate-800 dark:bg-slate-700">
              <div className="w-44 h-60 bg-white border border-slate-300 rounded-lg shadow-md p-3 relative overflow-hidden flex flex-col justify-between dark:bg-slate-800 dark:border-slate-700">
                {briefpapier ? (
                  <img
                    src={briefpapier.dataUrl}
                    alt="Briefpapier Vorschau"
                    className="absolute inset-0 w-full h-full object-cover opacity-90"
                  />
                ) : (
                  <div className="border-b border-slate-200 pb-1 text-left dark:border-slate-800">
                    <div className="w-12 h-1.5 bg-slate-300 rounded mb-1 dark:bg-slate-500"></div>
                    <div className="w-24 h-1 bg-slate-200 rounded dark:bg-slate-600"></div>
                  </div>
                )}
                <div className="relative z-10 text-left space-y-1.5">
                  <div className="w-20 h-2 bg-rose-200 rounded dark:bg-rose-900/60"></div>
                  <div className="w-32 h-1 bg-slate-300 rounded dark:bg-slate-500"></div>
                  <div className="w-28 h-1 bg-slate-300 rounded dark:bg-slate-500"></div>
                  <div className="w-36 h-1 bg-slate-200 rounded dark:bg-slate-600"></div>
                </div>
                <div className="relative z-10 border-t border-slate-200 pt-1 flex justify-between dark:border-slate-800">
                  <div className="w-8 h-1 bg-slate-300 rounded dark:bg-slate-500"></div>
                  <div className="w-8 h-1 bg-slate-300 rounded dark:bg-slate-500"></div>
                </div>
              </div>
              <span className="text-[11px] font-semibold text-slate-500 mt-3 dark:text-slate-400">
                DIN A4 Vorschau ({briefpapier ? 'Mit Briefpapier' : 'Standard-Layout'})
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      {/*
        Das Formular wird bei jedem Öffnen neu aufgebaut (bedingte Anzeige
        und `key`). Vorher blieb es dauerhaft eingehängt und übernahm seine
        Werte nur beim allerersten Anzeigen: Beim Bearbeiten erschienen die
        Angaben einer zuvor geöffneten Sitzung oder die Musterwerte, und das
        Speichern schrieb sie in die bearbeitete Sitzung (T-01).
      */}
      {isFormModalOpen && (
        <MeetingFormModal
          key={meetingToEdit?.id ?? 'neue-sitzung'}
          isOpen={isFormModalOpen}
          onClose={() => setIsFormModalOpen(false)}
          meetingToEdit={meetingToEdit}
          members={members}
          clubSettings={clubSettings}
          templateSettings={templateSettings}
          briefpapier={briefpapier}
          onSave={onSaveMeeting}
        />
      )}

      <MeetingTemplateModal
        isOpen={isTemplateModalOpen}
        onClose={() => setIsTemplateModalOpen(false)}
        templateSettings={templateSettings}
        clubSettings={clubSettings}
        onSaveTemplate={onSaveTemplate}
        rechnungsBriefpapier={Boolean(invoiceTemplateSettings?.customBlankoDataUrl?.trim())}
        onOpenBriefpapier={onOpenBriefpapier}
      />

      {/* PDF Download Choice Modal (if meeting has digital signatures) */}
      {downloadChoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4 dark:bg-slate-900 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center dark:bg-rose-900/40 dark:text-rose-300">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    PDF-Download Optionen
                  </h3>
                  <p className="text-xs text-slate-500 truncate max-w-[240px] dark:text-slate-400">
                    {downloadChoice.isExtract ? 'Registerauszug' : 'Protokoll'}: {downloadChoice.meeting.title}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDownloadChoice(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer dark:hover:text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              Für diese Sitzung liegen <strong>{downloadChoice.meeting.signatures?.length || 0} digitale Unterschriften</strong> vor. Wie möchten Sie das Dokument exportieren?
            </p>

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={() => handleExecuteDownloadPdf(downloadChoice.meeting, downloadChoice.isExtract, true)}
                className="w-full p-3 bg-rose-50 hover:bg-rose-100/80 border border-rose-200 rounded-xl text-left transition-colors flex items-center justify-between gap-3 cursor-pointer shadow-2xs group dark:bg-rose-950/40 dark:hover:bg-rose-900/80 dark:border-rose-800/60"
              >
                <div>
                  <span className="text-xs font-bold text-rose-900 flex items-center gap-1.5 group-hover:text-rose-950 dark:text-rose-100">
                    <PenTool className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                    Mit digitaler Unterschrift (PDF)
                  </span>
                  <p className="text-[11px] text-slate-600 mt-0.5 dark:text-slate-300">
                    Fügt die Unterschrift(en) und den amtlichen Zeitstempel direkt in das Dokument ein.
                  </p>
                </div>
                <Download className="w-4 h-4 text-rose-600 shrink-0 dark:text-rose-400" />
              </button>

              <button
                type="button"
                onClick={() => handleExecuteDownloadPdf(downloadChoice.meeting, downloadChoice.isExtract, false)}
                className="w-full p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-left transition-colors flex items-center justify-between gap-3 cursor-pointer shadow-2xs group dark:bg-slate-900 dark:hover:bg-slate-800 dark:border-slate-800"
              >
                <div>
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5 group-hover:text-slate-900 dark:text-slate-100 dark:group-hover:text-white">
                    <Download className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                    Ohne Unterschrift (Blanko-Signaturzeile)
                  </span>
                  <p className="text-[11px] text-slate-500 mt-0.5 dark:text-slate-400">
                    Erzeugt freie Linien zum klassischen Ausdrucken und handschriftlichen Unterzeichnen.
                  </p>
                </div>
                <Download className="w-4 h-4 text-slate-400 shrink-0" />
              </button>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setDownloadChoice(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer dark:text-slate-300 dark:hover:bg-slate-700"
              >
                Abbrechen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Signature Pad Modal */}
      {signatureModalMeeting && (
        <MeetingSignatureModal
          isOpen={Boolean(signatureModalMeeting)}
          onClose={() => setSignatureModalMeeting(null)}
          meeting={signatureModalMeeting}
          clubSettings={clubSettings}
          templateSettings={templateSettings}
          briefpapier={briefpapier}
          onSaveMeeting={async (updatedMeeting) => {
            await onSaveMeeting(updatedMeeting);
            setSignatureModalMeeting(updatedMeeting);
          }}
        />
      )}

      {/* Email Dispatch Modal */}
      {emailModalConfig && (
        <MeetingEmailModal
          isOpen={emailModalConfig.isOpen}
          onClose={() => setEmailModalConfig(null)}
          meeting={emailModalConfig.meeting}
          mode={emailModalConfig.mode}
          members={members}
          clubSettings={clubSettings}
          templateSettings={templateSettings}
          briefpapier={briefpapier}
        />
      )}
    </div>
  );
};
