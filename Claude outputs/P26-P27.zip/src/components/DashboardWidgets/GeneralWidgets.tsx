import React, { useMemo, useState, useEffect } from 'react';
import {
  ClubSettings,
  InventoryItem,
  ClubDocument,
  CalendarEvent,
  CalendarEventCategory
} from '../../types';
import { StorageService } from '../../services/storage';
import { kennzahlen } from '../../utils/inventarRegeln';
import { lokalesHeute } from '../../utils/mitgliedRegeln';
import { gemeinnuetzigText, termine } from '../../utils/dashboardRegeln';
import {
  Sparkles,
  Plus,
  CalendarDays,
  Package,
  FolderArchive,
  ArrowRight,
  MapPin,
  Clock,
  AlertTriangle
} from 'lucide-react';

// 1. Quick Actions Widget
/**
 * Schnellzugriff. Ein Knopf erscheint nur, wenn der Aufruf übergeben wurde —
 * die Startseite lässt die Aufrufe weg, für die das Schreibrecht fehlt.
 */
interface QuickActionsWidgetProps {
  onOpenCreateMember?: () => void;
  onOpenCreateTx?: () => void;
  onOpenCreateInvoice?: () => void;
  onOpenCreateContact?: () => void;
  onOpenCreateEvent?: () => void;
  onOpenCreateInventory?: () => void;
  onOpenNewDocument?: () => void;
}

export const QuickActionsWidget: React.FC<QuickActionsWidgetProps> = ({
  onOpenCreateMember,
  onOpenCreateTx,
  onOpenCreateInvoice,
  onOpenCreateContact,
  onOpenCreateEvent,
  onOpenCreateInventory,
  onOpenNewDocument
}) => {
  return (
    <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 h-full">
      <div className="space-y-1">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200/60 dark:border-blue-800/60 text-2xs font-bold uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          <span>Schnellzugriff</span>
        </div>
        <h3 className="text-base sm:text-lg font-black tracking-tight text-slate-900 dark:text-white">
          Was möchten Sie heute im Verein erfassen?
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Erstellen Sie Buchungen, Rechnungen, neue Mitglieder, Kontakte, Termine oder Dokumente mit einem Klick.
        </p>
      </div>

      <div className="vm-quick flex flex-wrap items-center gap-2">
        {onOpenCreateMember && (
          <button
            type="button"
            onClick={onOpenCreateMember}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all hover:scale-102 cursor-pointer active:scale-98"
          >
            <Plus className="w-4 h-4" />
            <span>Mitglied</span>
          </button>
        )}

        {onOpenCreateTx && (
          <button
            type="button"
            onClick={onOpenCreateTx}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all hover:scale-102 cursor-pointer active:scale-98"
          >
            <Plus className="w-4 h-4" />
            <span>Buchung</span>
          </button>
        )}

        {onOpenCreateInvoice && (
          <button
            type="button"
            onClick={onOpenCreateInvoice}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-green-600 hover:bg-green-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all hover:scale-102 cursor-pointer active:scale-98"
          >
            <Plus className="w-4 h-4" />
            <span>Rechnung</span>
          </button>
        )}

        {onOpenCreateContact && (
          <button
            type="button"
            onClick={onOpenCreateContact}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all hover:scale-102 cursor-pointer active:scale-98"
          >
            <Plus className="w-4 h-4" />
            <span>Kontakt</span>
          </button>
        )}

        {onOpenCreateEvent && (
          <button
            type="button"
            onClick={onOpenCreateEvent}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all hover:scale-102 cursor-pointer active:scale-98"
          >
            <Plus className="w-4 h-4" />
            <span>Termin</span>
          </button>
        )}

        {onOpenCreateInventory && (
          <button
            type="button"
            onClick={onOpenCreateInventory}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all hover:scale-102 cursor-pointer active:scale-98"
          >
            <Plus className="w-4 h-4" />
            <span>Material</span>
          </button>
        )}

        {onOpenNewDocument && (
          <button
            type="button"
            onClick={onOpenNewDocument}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all hover:scale-102 cursor-pointer active:scale-98"
          >
            <Plus className="w-4 h-4" />
            <span>Dokument</span>
          </button>
        )}
      </div>
    </div>
  );
};

// 2. Club Header Widget
interface ClubHeaderWidgetProps {
  settings: ClubSettings;
  onNavigate: (tab: string) => void;
}

export const ClubHeaderWidget: React.FC<ClubHeaderWidgetProps> = ({ settings, onNavigate }) => {
  return (
    <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 h-full">
      <div className="flex items-center gap-4 sm:gap-5">
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-2 flex items-center justify-center overflow-hidden shrink-0 shadow-2xs">
          <img
            src={settings.clubLogoUrl || '/logo_transparent.png'}
            alt="Vereinslogo"
            className="w-full h-full object-contain"
            onError={(e) => {
              if (e.currentTarget.src !== window.location.origin + '/logo_transparent.png') {
                e.currentTarget.src = '/logo_transparent.png';
              }
            }}
          />
        </div>
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-0.5 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200/60 dark:border-blue-800/60 rounded-full text-2xs font-bold uppercase tracking-wider">
              {settings.associationNumber || 'Eingetragener Verein (e.V.)'}
            </span>
            {/* Mit dem Datum des Bescheids, damit sein Alter sichtbar ist (D-140, wie Android) */}
            {gemeinnuetzigText(settings.taxExemptionDate) ? (
              <span className="px-2.5 py-0.5 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60 rounded-full text-2xs font-bold">
                {gemeinnuetzigText(settings.taxExemptionDate)}
              </span>
            ) : (
              <span className="px-2.5 py-0.5 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/60 rounded-full text-2xs font-bold">
                Kein Freistellungsbescheid hinterlegt
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight mt-0.5">
            {settings.clubName}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Vorstand: {settings.chairman || 'Unbekannt'} • Kassenwart: {settings.treasurer || 'Unbekannt'}
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={() => onNavigate('settings')}
        className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors shrink-0 cursor-pointer"
      >
        Vereinsstammdaten bearbeiten
      </button>
    </div>
  );
};

// 3. Upcoming Events & Calendar Widget
interface UpcomingEventsWidgetProps {
  onNavigate: (tab: string) => void;
  onOpenCreateEvent?: () => void;
  /**
   * Wird von App.tsx hochgezählt, sobald ein Termin gespeichert wurde.
   * Dadurch lädt die Kachel neu, statt bis zum nächsten Seitenwechsel
   * einen veralteten Stand zu zeigen.
   */
  refreshKey?: number;
}

/** Heutiges Datum als YYYY-MM-DD in der LOKALEN Zeitzone. */
function localDateKey(d: Date = new Date()): string {
  return [
    d.getFullYear(),
    String(d.getMonth() + 1).padStart(2, '0'),
    String(d.getDate()).padStart(2, '0')
  ].join('-');
}

export const UpcomingEventsWidget: React.FC<UpcomingEventsWidgetProps> = ({
  onNavigate,
  onOpenCreateEvent,
  refreshKey = 0
}) => {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [categories, setCategories] = useState<CalendarEventCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setIsLoading(true);
    Promise.all([StorageService.getCalendarEvents(), StorageService.getCalendarCategories()])
      .then(([loadedEvents, loadedCategories]) => {
        if (cancelled) return;
        setEvents(loadedEvents || []);
        setCategories(loadedCategories || []);
      })
      .catch(err => {
        console.warn('Termine für das Dashboard konnten nicht geladen werden:', err);
        if (!cancelled) {
          setEvents([]);
          setCategories([]);
        }
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  // Die nächsten drei Vorkommen, auch aus Serien (D-142); mehrtägige Termine bleiben
  // sichtbar, solange sie noch laufen.
  const upcoming = useMemo(() => termine(events, localDateKey()), [events]);

  const categoryOf = (categoryId: string) => categories.find(c => c.id === categoryId);

  const timeLabel = (evt: CalendarEvent) => {
    if (evt.isAllDay) return 'Ganztägig';
    if (evt.startTime && evt.endTime) return `${evt.startTime} - ${evt.endTime} Uhr`;
    if (evt.startTime) return `${evt.startTime} Uhr`;
    return 'Ohne Uhrzeit';
  };

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 h-full flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-xl">
              <CalendarDays className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Nächste Vereinstermine
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">Veranstaltungen & Fristen</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('calendar')}
            className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
          >
            Kalender öffnen <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {isLoading ? (
          <div className="py-8 text-center text-xs text-slate-400 dark:text-slate-500">
            Termine werden geladen...
          </div>
        ) : upcoming.length === 0 ? (
          <div className="py-8 text-center space-y-2">
            <CalendarDays className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600" />
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              Keine anstehenden Termine
            </p>
            <p className="text-2xs text-slate-400 dark:text-slate-500">
              Sobald im Kalender Termine erfasst sind, erscheinen die nächsten drei hier.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {upcoming.map(v => {
              const evt = v.originalEvent;
              const cat = categoryOf(evt.categoryId);
              return (
                <div
                  key={v.instanceId}
                  onClick={() => onNavigate('calendar')}
                  className="p-3 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl border border-slate-200/60 dark:border-slate-700/60 flex items-start justify-between gap-3 transition-colors cursor-pointer"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      {cat && (
                        <span
                          className={`text-[10px] uppercase font-bold px-1.5 py-0.2 rounded ${cat.badgeBg} ${cat.badgeText}`}
                        >
                          {cat.name}
                        </span>
                      )}
                      <span className="font-bold text-xs text-slate-900 dark:text-white truncate">
                        {evt.title}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-2xs text-slate-500 dark:text-slate-400 flex-wrap">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {timeLabel(evt)}
                      </span>
                      {evt.location && (
                        <span className="flex items-center gap-1 truncate max-w-[200px]">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          {evt.location}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="font-mono font-bold text-xs text-slate-800 dark:text-slate-200 block">
                      {new Date(`${v.date}T00:00:00`).toLocaleDateString('de-DE', {
                        day: '2-digit',
                        month: 'short'
                      })}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(`${v.date}T00:00:00`).toLocaleDateString('de-DE', {
                        weekday: 'short'
                      })}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-2xs text-slate-400">
        <span>
          {isLoading
            ? ''
            : events.length === 0
              ? 'Noch keine Termine erfasst'
              : `${events.length} Termin${events.length === 1 ? '' : 'e'} im Kalender`}
        </span>
        {onOpenCreateEvent && (
          <button
            type="button"
            onClick={onOpenCreateEvent}
            className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            + Termin anlegen
          </button>
        )}
      </div>
    </div>
  );
};

// 4. Inventory Widget
interface InventoryWidgetProps {
  inventory: InventoryItem[];
  onNavigate: (tab: string) => void;
}

export const InventoryWidget: React.FC<InventoryWidgetProps> = ({ inventory, onNavigate }) => {
  const { totalValue, totalQuantity, needsRepair } = useMemo(() => {
    // Dieselbe Rechnung wie die Inventarliste (D-101): Zeitwert, sonst
    // Anschaffungspreis, mal Menge; Ausgemustertes zählt nicht mit
    const k = kennzahlen(inventory, lokalesHeute());
    return { totalValue: k.wert, totalQuantity: k.einheiten, needsRepair: k.reparatur };
  }, [inventory]);

  return (
    <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs h-full flex flex-col justify-between space-y-3">
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 rounded-xl">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Inventar & Materialbestand
              </h3>
              <p className="text-2xs text-slate-500 dark:text-slate-400">Sachwerte des Vereins</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('inventory')}
            className="text-xs font-semibold text-purple-600 dark:text-purple-400 hover:underline"
          >
            Inventarliste
          </button>
        </div>

        <div className="space-y-2">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
            <span className="text-2xs text-slate-400 block font-semibold uppercase">Materieller Gesamtwert</span>
            <span className="text-2xl font-black font-mono text-slate-900 dark:text-white">
              {totalValue.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60">
              <span className="text-2xs text-slate-400 block">Positionen</span>
              <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{inventory.length} Artikel</span>
            </div>
            <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60">
              <span className="text-2xs text-slate-400 block">Gesamtstückzahl</span>
              <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{totalQuantity} Stk.</span>
            </div>
          </div>

          {needsRepair > 0 && (
            <div className="flex items-center gap-1.5 text-2xs text-amber-600 dark:text-amber-400 font-semibold p-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{needsRepair} Gegenstand / Material wartungsbedürftig</span>
            </div>
          )}
        </div>
      </div>

      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-2xs text-slate-400 flex items-center justify-between">
        <span>Sportgeräte & Ausstattung</span>
        <span className="font-bold text-purple-600 dark:text-purple-400">QR-Code Etiketten</span>
      </div>
    </div>
  );
};

// 5. Documents Archive Widget
interface DocumentsArchiveWidgetProps {
  documents: ClubDocument[];
  onNavigate: (tab: string) => void;
}

export const DocumentsArchiveWidget: React.FC<DocumentsArchiveWidgetProps> = ({
  documents,
  onNavigate
}) => {
  const { receiptsCount, contractsCount, protocolsCount } = useMemo(() => {
    let r = 0, c = 0, p = 0;
    documents.forEach((d) => {
      if (d.category === 'belege') r++;
      else if (d.category === 'vertraege') c++;
      else if (d.category === 'protokolle') p++;
    });
    return { receiptsCount: r, contractsCount: c, protocolsCount: p };
  }, [documents]);

  return (
    <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs h-full flex flex-col justify-between space-y-3">
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 rounded-xl">
              <FolderArchive className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Dokumentenarchiv & Belege
              </h3>
              <p className="text-2xs text-slate-500 dark:text-slate-400">Digitale Vereinsablage</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('documents')}
            className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline"
          >
            Archiv
          </button>
        </div>

        <div className="space-y-2">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl flex items-center justify-between">
            <div>
              <span className="text-2xs text-slate-400 block font-semibold uppercase">Gesamtdokumente</span>
              <span className="text-2xl font-black font-mono text-slate-900 dark:text-white">
                {documents.length}
              </span>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 text-2xs font-bold">
              GoBD revisionssicher
            </span>
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-center text-xs">
            <div className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60">
              <span className="text-3xs text-slate-400 block uppercase">Belege</span>
              <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{receiptsCount}</span>
            </div>
            <div className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60">
              <span className="text-3xs text-slate-400 block uppercase">Verträge</span>
              <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{contractsCount}</span>
            </div>
            <div className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60">
              <span className="text-3xs text-slate-400 block uppercase">Protokolle</span>
              <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{protocolsCount}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-2xs text-slate-400 flex items-center justify-between">
        <span>Lokaler OCR-Scan & Volltextsuche</span>
        <span className="font-bold text-amber-600 dark:text-amber-400">PDF & Bilder</span>
      </div>
    </div>
  );
};
